from rest_framework.serializers import ModelSerializer
from rest_framework.fields import CharField

from app.models import Supplier, Item, ItemCategory, Purchase, Quality, Tapeline, TapeType, TapeStock, Inventory, \
    Customer, Stereo, BagType, Order, Loom, LoomStock, Printing, Dispatch


class SupplierSerializer(ModelSerializer):
    class Meta:
        model = Supplier
        fields = ("id", "name", "address", "contact", "email", "NTN", "GST")


class ItemSerializer(ModelSerializer):
    class Meta:
        model = Item
        fields = ("id", "category", "name",)


class ItemCategorySerializer(ModelSerializer):
    class Meta:
        model = ItemCategory
        fields = ("id", "name",)


class PurchaseSerializer(ModelSerializer):

    supplier_name = CharField(source="supplier.name", read_only=True)
    item_name = CharField(source="item.name", read_only=True)
    item_category = CharField(source="item.category", read_only=True)

    class Meta:
        model = Purchase
        fields = ("id", "date", "supplier", "item", "unit","quantity", "price", "comments", "supplier_name", "item_name", "item_category")

    def create(self, v):

        i, created = Inventory.objects.get_or_create(item=v["item"], defaults={
            "quantity": v["quantity"],
            "price": v["price"]
        })

        if created:
            return Purchase.objects.create(**v)
        else:
            i.quantity = i.quantity + v["quantity"]
            i.price = i.price + v["price"]
            i.save()
            return Purchase.objects.create(**v)





class InventorySerializer(ModelSerializer):
    item_name = CharField(source="item.name", read_only=True)
    item_category = CharField(source="item.category", read_only=True)
    class Meta:
        model = Inventory
        fields = ("id","item", "quantity", "price", "item_name", "item_category")



class LoomSerializer(ModelSerializer):
    class Meta:
        model = Loom
        fields = ("id", "loom_number",  "tap_type" ,"bag_type", "quantity", )


class LoomStockSerializer(ModelSerializer):
    class Meta:
        model = LoomStock
        fields = ("id", "loom", "quantity", )


class PrintingSerializer(ModelSerializer):
    class Meta:
        model = Printing
        fields = ("id", "loom_stock", "stereo", "quantity", )


class DispatchSerializer(ModelSerializer):
    class Meta:
        model = Dispatch
        fields = ("id", "printing", "customer", "quantity", "dispatch_time",)

#
#


class QualitySerializer(ModelSerializer):
    class Meta:
        model = Quality
        fields=("id","name")


class TapeTypeSerializer(ModelSerializer):
    class Meta:
        model = TapeType
        fields = ("id", "quality", "denier", "color",)


class TapeStockSerializer(ModelSerializer):
    class Meta:
        model = TapeStock
        fields = ("id", "tape_type_id", "quantity",)


class TapelineSerializer(ModelSerializer):

    item_name = CharField(source="inventory.item.name", read_only=True)

    tape_type = TapeTypeSerializer()

    class Meta:
        model = Tapeline
        fields = ("id", "batch_id", "inventory", "tape_type", "quantity", "item_name")

    def create(self, validated_data):
        tape_type = validated_data.pop("tape_type")
        tape_type_obj, created = TapeType.objects.get_or_create(**tape_type)
        tapeline = Tapeline.objects.create(**validated_data, tape_type=tape_type_obj)

        # Update inventory
        i = validated_data["inventory"]
        price_per_kg = i.price/i.quantity;
        i.quantity = i.quantity - validated_data["quantity"]
        i.price = i.price - (validated_data["quantity"]*price_per_kg)
        i.save()

        # update Tapestock
        try:
            i = TapeStock.objects.get(tape_type_id=tape_type_obj.id)
            i.quantity = i.quantity + validated_data["quantity"]
            i.save()

        except:
            i = TapeStock.objects.create(tape_type_id=tape_type_obj.id, quantity=validated_data["quantity"])

        return tapeline

    def update(self, instance, validated_data):
        tape_type = validated_data.pop("tape_type")

        tape_type_obj, created = TapeType.objects.get_or_create(**tape_type)

        instance.tape_type = tape_type_obj

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.save()

        return instance





class CustomerSerializer(ModelSerializer):
    class Meta:
        model = Customer
        fields = ("id", "name", "address", "contact", "email", "NTN", "GST",)


class StereoSerializer(ModelSerializer):
    class Meta:
        model = Stereo
        fields = ("id", "name", "width", "length",)


class BagTypeSerializer(ModelSerializer):
    class Meta:
        model = BagType
        fields = ("id", "width", "length", "frame", "color",)


class OrderSerializer(ModelSerializer):

    bag_type = BagTypeSerializer()
    #stereo = StereoSerializer()

    class Meta:
        model = Order
        fields = ("id", "date", "customer", "stereo", "bag_type", "quality" , "quantity",)

    def create(self, validated_data):
      #  stereo = validated_data.pop("stereo")
        bag_type = validated_data.pop("bag_type")

       # stereo_obj, created = Stereo.objects.get_or_create(**stereo)
        bag_type_obj, created = BagType.objects.get_or_create(**bag_type)

        order = Order.objects.create(**validated_data, bag_type=bag_type_obj)

        return order

    def update(self, instance, validated_data):
       # stereo = validated_data.pop("stereo")
        bag_type = validated_data.pop("bag_type")

        #stereo_obj, created = Stereo.objects.get_or_create(**stereo)
        bag_type_obj, created = BagType.objects.get_or_create(**bag_type)

        #instance.stereo = stereo_obj
        instance.bag_type = bag_type_obj

        for attr, value in validated_data.items():
            setattr(instance, attr, value)

        instance.save()

        return instance
