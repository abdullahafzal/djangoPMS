# from celery.app import task
#
#
# @task
# def see_you():
#     print("See you in ten seconds!")