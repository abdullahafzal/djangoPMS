from __future__ import absolute_import
import os
from celery import Celery
from django.conf import settings
# set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'pms_project.settings')
app = Celery('pms_project')

# Using a string here means the worker will not have to
# pickle the object when using Windows.
app.config_from_object('django.conf:settings')
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)


@app.task(bind=True)
def debug_task(self):
    print('Request: {0!r}'.format(self.request))

@app.task
def see_you():
    import requests
    import re
    from app.models import RpmReading

    url = "http://192.168.43.219"
    response = requests.get(url)
    mac_regex = r"<H2>\s+(.+)\s+</H2>"
    machine_no_regex = r"<H3>\s+Machine\s+(\d+)"
    RPM_regex = r"RPM\s+:\s+(\d+)"

    mac = re.findall(mac_regex, response.text)
    machine_no = re.findall(machine_no_regex, response.text)
    rpm = re.findall(RPM_regex, response.text)
    print(mac, machine_no, rpm)
    if mac and machine_no and rpm:
        RpmReading.objects.create(machine_no=int(machine_no[0]), mac_address=mac[0], rpm=int(rpm[0]))


app.conf.beat_schedule = {
    "see-you-in-ten-seconds-task": {
        "task": "pms_project.celery.see_you",
        "schedule": 60.0
    }
}