from django.contrib import admin

# Register your models here.
from app.models import RpmReading

admin.site.register(RpmReading)
